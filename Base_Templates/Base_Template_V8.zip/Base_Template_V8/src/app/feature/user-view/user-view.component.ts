import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm } from '@angular/forms';

import { FirstLetterPipe } from '../../util/firstLetter.pipe';
import { UserService } from '../../service/user-service/user.service';
import { UserModule } from '../../module/user/user.module';

@Component({
  selector: 'app-feature-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.css'],
  providers: [ FirstLetterPipe ]
})

export class UserViewComponent {

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
  ) { }

  items = this.userService.getItems();

  checkoutForm = this.formBuilder.group({
    first_name: '',
    last_name: '',
    home_town: ''
  });

  share() {
    window.alert('The product has been shared!');
  }

  onSubmit(): void {
    console.warn('Your record has been submitted', this.checkoutForm.value);
    this.addToList(Object.assign({id: this.items.length + 1}, this.checkoutForm.value));
    this.checkoutForm.reset();
  }

  onDelete(item: any): void {
    this.deleteItem(item);
  }

  addToList(user: UserModule) {
    this.userService.addToList(user);
    // window.alert('New user has been added to the list!');
  }

  deleteItem(user: UserModule) {
    this.userService.deleteItem(user);
    // window.alert('User has been deleted!');
  }

}
