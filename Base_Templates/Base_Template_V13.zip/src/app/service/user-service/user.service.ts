import { Injectable } from '@angular/core';
import { UserModule } from '../../module/user/user.module';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private users = [
    {
      id: 1,
      first_name: 'Darsha',
      last_name: 'Hewavitharana',
      home_town: 'Galle'
    },
    {
      id: 2,
      first_name: 'Kasun',
      last_name: 'Maleesha',
      home_town: 'Colombo'
    },
    {
      id: 3,
      first_name: 'Ravindu',
      last_name: 'Godage',
      home_town: 'Kandy'
    }
  ];

  items: UserModule[] = this.users;

  constructor() { }

  addToList(user: UserModule) {
    this.items.push(user);
  }

  getItems() {
    return this.items;
  }

  clearList() {
    this.items = [];
    return this.items;
  }

  deleteItem(user: UserModule) {
    this.items.splice(this.items.indexOf(user), 1);
  }

}
