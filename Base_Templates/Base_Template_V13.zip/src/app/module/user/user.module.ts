import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface UserModule {
  id: number;
  first_name: string;
  last_name: string;
  home_town: string;
 }
